extends Area2D

# Velocidad de la bala de cañón en píxeles por segundo
var speed = 800
# Dirección en la que se moverá la bala (hacia arriba por defecto)
var direction = Vector2(0, -1)

func _process(delta):
	# Mueve la bala en cada fotograma
	position += direction * speed * delta

# Esta función se llama cuando la bala choca con un enemigo
func _on_body_entered(body):
	# Si el cuerpo con el que choca pertenece al grupo "mobs"
	if body.is_in_group("mobs"):
		body.queue_free() # Destruye al enemigo
		queue_free() # Destruye la bala también
